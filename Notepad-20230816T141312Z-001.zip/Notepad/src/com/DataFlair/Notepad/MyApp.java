package com.DataFlair.Notepad;

public class MyApp 
{
	public static void main(String args[])
	{ 
	    NotePad notp=new NotePad();
	}
	}
